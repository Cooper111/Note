package com.xzg.cd.rpc.demo.client;

public interface CalculatorService {

  int add(int a, int b);

}
