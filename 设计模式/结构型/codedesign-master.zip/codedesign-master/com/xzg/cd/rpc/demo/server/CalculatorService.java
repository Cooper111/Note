package com.xzg.cd.rpc.demo.server;

public interface CalculatorService {

  int add(int a, int b);

}
